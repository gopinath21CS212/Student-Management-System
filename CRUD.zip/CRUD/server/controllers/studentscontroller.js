const mysql = require("mysql");
// MySQL
const con = mysql.createPool({
  connectionLimit: 10,
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME
});

// // Check DB connection
exports.view = (req, res) => {
    con.getConnection((err, connection) => {
      if (err) {
        console.error('Error connecting to the database:', err);
        throw err;
      }
  
      connection.query("SELECT * FROM users", (err, rows) => {
        connection.release();
        
        if (err) {
          console.error('Error in listing data:', err);
          return;
        }
  
        res.render("home", { users: rows });
      });
    });
  };
  
  exports.adduser=(req,res)=>{
    res.render("adduser")
  }
  //insert

  exports.save = (req, res) => {
    con.getConnection((err, connection) => {
      if (err) {
        console.error('Error connecting to the database:', err);
        return res.status(500).send('Internal Server Error');
      }
      
      const { name, age, city } = req.body;
      
      connection.query("INSERT INTO users (Name, AGE, CITY) VALUES (?, ?, ?)", [name, age, city], (err, rows) => {
        connection.release();
        
        if (err) {
          console.error('Error inserting data:', err);
          return res.status(500).send('Internal Server Error');
        }
  
        res.render("adduser",{msg:"User Details Added Successfully"});
      });
    });
  };
  //edit
  exports.edituser = (req, res) => {
    con.getConnection((err, connection) => {
      if (err) {
        console.error('Error connecting to the database:', err);
        throw err;
      }
      let id = req.params.id;
      connection.query("SELECT * FROM users WHERE id=?", [id], (err, rows) => {
        connection.release();
  
        if (err) {
          console.error('Error in listing data:', err);
          res.status(500).send('Error fetching user data');
          return;
        }
  
        // Assuming there's only one user with this ID, so rows[0] contains user data
        res.render("edituser", { user: rows[0] });
      });
    });
  };
  //update
  exports.edit = (req, res) => {
    con.getConnection((err, connection) => {
      if (err) {
        console.error('Error connecting to the database:', err);
        return res.status(500).send('Internal Server Error');
      }
      
      const { name, age, city } = req.body;
      const id = req.params.id;
      
      connection.query("UPDATE users SET Name=?, AGE=?, CITY=? WHERE id=?", [name, age, city, id], (err, result) => {
        connection.release();
        
        if (err) {
          console.error('Error updating data:', err);
          return res.status(500).send('Internal Server Error');
        }
  
        if (result.affectedRows === 0) {
          return res.status(404).send('User not found');
        }
  
        res.render("adduser", { msg: "User Details Updated Successfully" });
      });
    });
  };
  
  exports.delete = (req, res) => {
    con.getConnection((err, connection) => {
      if (err) {
        console.error('Error connecting to the database:', err);
        res.status(500).send('Error connecting to the database');
        return;
      }
  
      // Get id from URL
      let id = req.params.id;
  
      connection.query('DELETE FROM users WHERE id = ?', [id], (err, rows) => {
        // Release the connection
        connection.release();
  
        if (!err) {
          res.redirect('/');
        } else {
          console.error('Error executing the query:', err);
          res.status(500).send('Error executing the query');
        }
      });
    });
  };
  